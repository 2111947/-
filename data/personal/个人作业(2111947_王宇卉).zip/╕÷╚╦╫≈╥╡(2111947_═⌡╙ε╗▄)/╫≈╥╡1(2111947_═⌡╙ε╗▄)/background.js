chrome.runtime.onStartup.addListener(() => {
    chrome.tabs.create({ url: "https://www.huangli.com/huangli/" });
});

// 在浏览器启动时如果有打开的窗口，自动跳转
chrome.windows.onCreated.addListener((window) => {
    if (window.tabs.length === 1) {
        chrome.tabs.create({ url: "https://www.huangli.com/huangli/" });
    }
});